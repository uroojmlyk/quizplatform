// 'use client';

// import { useEffect, useState } from 'react';
// import { Users, BookOpen, CheckCircle, Clock } from 'lucide-react';

// interface Stats {
//   totalUsers: number;
//   totalQuizzes: number;
//   activeUsers: number;
//   completionRate: number;
// }

// export default function AdminDashboard() {
//   const [stats, setStats] = useState<Stats>({
//     totalUsers: 0,
//     totalQuizzes: 0,
//     activeUsers: 0,
//     completionRate: 0
//   });
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     fetchStats();
//   }, []);

//   const fetchStats = async () => {
//     try {
//       const res = await fetch('/api/admin/dashboard');
//       const data = await res.json();
      
//       if (data.success) {
//         setStats(data.data);
//       }
//     } catch (error) {
//       console.error('Error fetching stats:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const statCards = [
//     {
//       title: 'Total Users',
//       value: stats.totalUsers,
//       icon: Users,
//       change: '+12 this week',
//       color: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
//     },
//     {
//       title: 'Total Quizzes',
//       value: stats.totalQuizzes,
//       icon: BookOpen,
//       change: '+5 this week',
//       color: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
//     },
//     {
//       title: 'Active Users',
//       value: stats.activeUsers,
//       icon: Clock,
//       change: 'last 7 days',
//       color: 'bg-green-500/10 text-green-400 border-green-500/20'
//     },
//     {
//       title: 'Completion Rate',
//       value: `${stats.completionRate}%`,
//       icon: CheckCircle,
//       change: '+8% vs last month',
//       color: 'bg-orange-500/10 text-orange-400 border-orange-500/20'
//     },
//   ];

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-64">
//         <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
//       </div>
//     );
//   }

//   return (
//     <div>
//       {/* Header */}
//       <div className="mb-8">
//         <h1 className="text-2xl font-medium text-white mb-2">Dashboard Overview</h1>
//         <p className="text-white/40 text-sm">Welcome back, Admin. Here's what's happening.</p>
//       </div>

//       {/* Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
//         {statCards.map((stat) => (
//           <div
//             key={stat.title}
//             className="bg-[#111117] border border-white/10 rounded-xl p-6 hover:border-white/20 transition-colors"
//           >
//             <div className="flex items-center justify-between mb-4">
//               <div className={`p-3 rounded-lg border ${stat.color}`}>
//                 <stat.icon className="w-5 h-5" />
//               </div>
//             </div>
//             <p className="text-2xl font-medium text-white mb-1">{stat.value}</p>
//             <p className="text-sm text-white/40 mb-2">{stat.title}</p>
//             <p className="text-xs text-white/20">{stat.change}</p>
//           </div>
//         ))}
//       </div>

//       {/* Recent Activity Placeholder */}
//       <div className="bg-[#111117] border border-white/10 rounded-xl p-6">
//         <h2 className="text-lg font-medium text-white mb-4">Recent Activity</h2>
//         <div className="space-y-4">
//           {[1, 2, 3, 4, 5].map((i) => (
//             <div key={i} className="flex items-center gap-4 py-2 border-b border-white/5 last:border-0">
//               <div className="w-8 h-8 bg-white/5 rounded-full flex items-center justify-center">
//                 <span className="text-xs text-white/40">{i}</span>
//               </div>
//               <div className="flex-1">
//                 <p className="text-sm text-white/80">New user registered</p>
//                 <p className="text-xs text-white/30">2 minutes ago</p>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }








// 'use client';

// import { useEffect, useState } from 'react';
// import { useRouter } from 'next/navigation';
// import Link from 'next/link';
// import { 
//   Users, 
//   BookOpen, 
//   CheckCircle, 
//   Clock,
//   TrendingUp,
//   UserPlus,
//   Award,
//   Eye,
//   ChevronRight,
//   Calendar,
//   Activity,
//   Target,
//   Zap
// } from 'lucide-react';

// interface Stats {
//   totalUsers: number;
//   totalQuizzes: number;
//   activeUsers: number;
//   completionRate: number;
//   newUsersToday: number;
//   quizzesToday: number;
//   totalAttempts: number;
//   avgScore: number;
// }

// interface RecentActivity {
//   id: string;
//   type: 'user' | 'quiz' | 'result';
//   message: string;
//   time: string;
//   userId?: string;
//   quizId?: string;
// }

// export default function AdminDashboard() {
//   const router = useRouter();
//   const [stats, setStats] = useState<Stats>({
//     totalUsers: 0,
//     totalQuizzes: 0,
//     activeUsers: 0,
//     completionRate: 0,
//     newUsersToday: 0,
//     quizzesToday: 0,
//     totalAttempts: 0,
//     avgScore: 0
//   });
//   const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     fetchDashboardData();
//   }, []);

//   const fetchDashboardData = async () => {
//     try {
//       // Fetch main stats
//       const statsRes = await fetch('/api/admin/dashboard');
//       const statsData = await statsRes.json();
      
//       if (statsData.success) {
//         setStats(statsData.data);
//       }

//       // Fetch recent activity
//       const activityRes = await fetch('/api/admin/recent-activity');
//       const activityData = await activityRes.json();
      
//       if (activityData.success) {
//         setRecentActivity(activityData.data);
//       } else {
//         // Fallback mock data
//         setRecentActivity([
//           { id: '1', type: 'user', message: 'New user registered', time: '2 minutes ago' },
//           { id: '2', type: 'quiz', message: 'New quiz created', time: '15 minutes ago' },
//           { id: '3', type: 'result', message: 'Quiz completed', time: '1 hour ago' },
//           { id: '4', type: 'user', message: 'Teacher account approved', time: '2 hours ago' },
//           { id: '5', type: 'quiz', message: 'Quiz attempted 50 times', time: '3 hours ago' },
//         ]);
//       }
//     } catch (error) {
//       console.error('Error fetching dashboard data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const statCards = [
//     {
//       title: 'Total Users',
//       value: stats.totalUsers,
//       icon: Users,
//       change: `+${stats.newUsersToday} today`,
//       href: '/admin/admin-users',
//       color: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
//       hoverColor: 'hover:bg-blue-500/20'
//     },
//     {
//       title: 'Total Quizzes',
//       value: stats.totalQuizzes,
//       icon: BookOpen,
//       change: `+${stats.quizzesToday} today`,
//       href: '/admin/admin-quizzes',
//       color: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
//       hoverColor: 'hover:bg-purple-500/20'
//     },
//     {
//       title: 'Active Users',
//       value: stats.activeUsers,
//       icon: Activity,
//       change: 'last 7 days',
//       href: '/admin/admin-users?filter=active',
//       color: 'bg-green-500/10 text-green-400 border-green-500/20',
//       hoverColor: 'hover:bg-green-500/20'
//     },
//     {
//       title: 'Completion Rate',
//       value: `${stats.completionRate}%`,
//       icon: Target,
//       change: 'avg. score',
//       href: '/admin/reports',
//       color: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
//       hoverColor: 'hover:bg-orange-500/20'
//     },
//   ];

//   const miniStats = [
//     {
//       title: 'Total Attempts',
//       value: stats.totalAttempts,
//       icon: Award,
//       change: 'all time',
//       color: 'text-pink-400'
//     },
//     {
//       title: 'Avg. Score',
//       value: `${stats.avgScore}%`,
//       icon: TrendingUp,
//       change: 'overall',
//       color: 'text-yellow-400'
//     },
//   ];

//   const getActivityIcon = (type: string) => {
//     switch(type) {
//       case 'user': return <UserPlus className="w-4 h-4 text-blue-400" />;
//       case 'quiz': return <BookOpen className="w-4 h-4 text-purple-400" />;
//       case 'result': return <CheckCircle className="w-4 h-4 text-green-400" />;
//       default: return <Clock className="w-4 h-4 text-gray-400" />;
//     }
//   };

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-64">
//         <div className="relative">
//           <div className="w-12 h-12 border-4 border-white/10 border-t-white rounded-full animate-spin"></div>
//           <div className="absolute inset-0 flex items-center justify-center">
//             <Zap className="w-5 h-5 text-white/40 animate-pulse" />
//           </div>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-6">
//       {/* Header with Quick Actions */}
//       <div className="flex items-center justify-between">
//         <div>
//           <h1 className="text-2xl font-semibold text-white">Dashboard</h1>
//           <p className="text-sm text-white/40 mt-1">
//             Welcome back, Admin. Here's what's happening with your platform.
//           </p>
//         </div>
//         <div className="flex gap-3">
//           <button
//             onClick={() => router.push('/admin/reports')}
//             className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm text-white/80 hover:text-white transition-colors flex items-center gap-2 border border-white/10"
//           >
//             <TrendingUp className="w-4 h-4" />
//             View Reports
//           </button>
//           <button
//             onClick={() => router.push('/admin/admin-users')}
//             className="px-4 py-2 bg-white/10 hover:bg-white/15 rounded-lg text-sm text-white transition-colors flex items-center gap-2"
//           >
//             <Users className="w-4 h-4" />
//             Manage Users
//           </button>
//         </div>
//       </div>

//       {/* Main Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
//         {statCards.map((stat) => (
//           <Link
//             key={stat.title}
//             href={stat.href}
//             className="group block bg-[#111117] border border-white/10 rounded-xl p-6 hover:border-white/20 transition-all hover:scale-[1.02] cursor-pointer"
//           >
//             <div className="flex items-center justify-between mb-4">
//               <div className={`p-3 rounded-lg border ${stat.color} group-hover:scale-110 transition-transform`}>
//                 <stat.icon className="w-5 h-5" />
//               </div>
//               <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors" />
//             </div>
//             <p className="text-2xl font-semibold text-white mb-1">{stat.value}</p>
//             <p className="text-sm text-white/40 mb-2">{stat.title}</p>
//             <p className="text-xs text-white/20 flex items-center gap-1">
//               <Clock className="w-3 h-3" />
//               {stat.change}
//             </p>
//           </Link>
//         ))}
//       </div>

//       {/* Mini Stats Row */}
//       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//         {miniStats.map((stat) => (
//           <div
//             key={stat.title}
//             className="bg-[#111117] border border-white/10 rounded-xl p-4 flex items-center justify-between"
//           >
//             <div>
//               <p className="text-sm text-white/40 mb-1">{stat.title}</p>
//               <p className="text-2xl font-semibold text-white">{stat.value}</p>
//               <p className="text-xs text-white/20 mt-1">{stat.change}</p>
//             </div>
//             <div className={`p-3 rounded-lg bg-white/5 border border-white/10 ${stat.color}`}>
//               <stat.icon className="w-5 h-5" />
//             </div>
//           </div>
//         ))}
//       </div>

//       {/* Recent Activity with Links */}
//       <div className="bg-[#111117] border border-white/10 rounded-xl overflow-hidden">
//         <div className="p-5 border-b border-white/10 flex items-center justify-between">
//           <div className="flex items-center gap-2">
//             <Activity className="w-5 h-5 text-purple-400" />
//             <h2 className="text-base font-medium text-white">Recent Activity</h2>
//           </div>
//           <Link
//             href="/admin/reports"
//             className="text-xs text-white/40 hover:text-white/60 transition-colors flex items-center gap-1"
//           >
//             View all
//             <ChevronRight className="w-3 h-3" />
//           </Link>
//         </div>
        
//         <div className="divide-y divide-white/5">
//           {recentActivity.map((activity) => (
//             <div
//               key={activity.id}
//               className="flex items-center gap-4 px-5 py-3 hover:bg-white/5 transition-colors group cursor-pointer"
//               onClick={() => {
//                 if (activity.type === 'user' && activity.userId) {
//                   router.push(`/admin/admin-users/${activity.userId}`);
//                 } else if (activity.type === 'quiz' && activity.quizId) {
//                   router.push(`/admin/admin-quizzes/${activity.quizId}`);
//                 }
//               }}
//             >
//               <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
//                 {getActivityIcon(activity.type)}
//               </div>
//               <div className="flex-1">
//                 <p className="text-sm text-white/80 group-hover:text-white transition-colors">
//                   {activity.message}
//                 </p>
//                 <p className="text-xs text-white/30 flex items-center gap-1 mt-0.5">
//                   <Calendar className="w-3 h-3" />
//                   {activity.time}
//                 </p>
//               </div>
//               <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors" />
//             </div>
//           ))}
//         </div>
//       </div>

//       {/* Quick Actions Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//         <Link
//           href="/admin/admin-users"
//           className="bg-gradient-to-br from-blue-600/20 to-blue-600/5 border border-blue-500/20 rounded-xl p-4 hover:scale-[1.02] transition-all"
//         >
//           <div className="flex items-center gap-3 mb-2">
//             <Users className="w-5 h-5 text-blue-400" />
//             <span className="text-sm font-medium text-white">User Management</span>
//           </div>
//           <p className="text-xs text-white/40">View, edit, and manage all users</p>
//         </Link>

//         <Link
//           href="/admin/admin-quizzes"
//           className="bg-gradient-to-br from-purple-600/20 to-purple-600/5 border border-purple-500/20 rounded-xl p-4 hover:scale-[1.02] transition-all"
//         >
//           <div className="flex items-center gap-3 mb-2">
//             <BookOpen className="w-5 h-5 text-purple-400" />
//             <span className="text-sm font-medium text-white">Quiz Management</span>
//           </div>
//           <p className="text-xs text-white/40">Monitor and manage all quizzes</p>
//         </Link>

//         <Link
//           href="/admin/reports"
//           className="bg-gradient-to-br from-orange-600/20 to-orange-600/5 border border-orange-500/20 rounded-xl p-4 hover:scale-[1.02] transition-all"
//         >
//           <div className="flex items-center gap-3 mb-2">
//             <TrendingUp className="w-5 h-5 text-orange-400" />
//             <span className="text-sm font-medium text-white">Analytics</span>
//           </div>
//           <p className="text-xs text-white/40">View reports and insights</p>
//         </Link>
//       </div>
//     </div>
//   );
// }








// 'use client';

// import { useEffect, useState } from 'react';
// import { useRouter } from 'next/navigation';
// import Link from 'next/link';
// import {
//   Users,
//   BookOpen,
//   CheckCircle,
//   Clock,
//   TrendingUp,
//   UserPlus,
//   Award,
//   Activity,
//   Target,
//   Zap,
//   ChevronRight,
//   Calendar,
//   ArrowUpRight,
//   BarChart3
// } from 'lucide-react';

// interface Stats {
//   totalUsers: number;
//   totalQuizzes: number;
//   activeUsers: number;
//   completionRate: number;
//   newUsersToday: number;
//   quizzesToday: number;
//   totalAttempts: number;
//   avgScore: number;
// }

// interface RecentActivity {
//   id: string;
//   type: 'user' | 'quiz' | 'result';
//   message: string;
//   time: string;
//   userId?: string;
//   quizId?: string;
// }

// const StatCard = ({
//   title, value, icon: Icon, change, href, accent
// }: {
//   title: string; value: string | number; icon: any; change: string; href: string; accent: string;
// }) => (
//   <Link
//     href={href}
//     className="group block rounded-2xl p-5 border transition-all duration-200 hover:scale-[1.02]"
//     style={{
//       background: 'rgba(255,255,255,0.02)',
//       borderColor: 'rgba(255,255,255,0.06)'
//     }}
//     onMouseEnter={e => (e.currentTarget.style.borderColor = `${accent}35`)}
//     onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)')}
//   >
//     <div className="flex items-start justify-between mb-4">
//       <div
//         className="w-10 h-10 rounded-xl flex items-center justify-center"
//         style={{ background: `${accent}18`, border: `1px solid ${accent}25` }}
//       >
//         <Icon className="w-5 h-5" style={{ color: accent }} />
//       </div>
//       <ArrowUpRight className="w-4 h-4 text-white/15 group-hover:text-white/40 transition-colors" />
//     </div>
//     <p className="text-2xl font-semibold text-white mb-1">{value}</p>
//     <p className="text-sm text-white/40 mb-3">{title}</p>
//     <div className="flex items-center gap-1.5 text-xs text-white/20">
//       <Clock className="w-3 h-3" />
//       <span>{change}</span>
//     </div>
//   </Link>
// );

// const activityIcon = (type: string) => {
//   const map: Record<string, { icon: any; color: string }> = {
//     user: { icon: UserPlus, color: '#6366f1' },
//     quiz: { icon: BookOpen, color: '#8b5cf6' },
//     result: { icon: CheckCircle, color: '#10b981' },
//   };
//   const { icon: Icon, color } = map[type] || { icon: Clock, color: '#6b7280' };
//   return <Icon className="w-4 h-4" style={{ color }} />;
// };

// export default function AdminDashboard() {
//   const router = useRouter();
//   const [stats, setStats] = useState<Stats>({
//     totalUsers: 0, totalQuizzes: 0, activeUsers: 0,
//     completionRate: 0, newUsersToday: 0, quizzesToday: 0,
//     totalAttempts: 0, avgScore: 0
//   });
//   const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => { fetchDashboardData(); }, []);

//   const fetchDashboardData = async () => {
//     try {
//       const [statsRes, activityRes] = await Promise.all([
//         fetch('/api/admin/dashboard'),
//         fetch('/api/admin/recent-activity')
//       ]);
//       const statsData = await statsRes.json();
//       if (statsData.success) setStats(statsData.data);

//       const activityData = await activityRes.json();
//       if (activityData.success) {
//         setRecentActivity(activityData.data);
//       } else {
//         setRecentActivity([
//           { id: '1', type: 'user', message: 'New user registered', time: '2 minutes ago' },
//           { id: '2', type: 'quiz', message: 'New quiz created', time: '15 minutes ago' },
//           { id: '3', type: 'result', message: 'Quiz completed with 94% score', time: '1 hour ago' },
//           { id: '4', type: 'user', message: 'Teacher account approved', time: '2 hours ago' },
//           { id: '5', type: 'quiz', message: 'Quiz attempted 50 times', time: '3 hours ago' },
//         ]);
//       }
//     } catch (err) {
//       console.error(err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-72">
//         <div className="relative">
//           <div className="w-10 h-10 rounded-full border-2 border-indigo-500/20 border-t-indigo-400 animate-spin" />
//           <div className="absolute inset-0 flex items-center justify-center">
//             <Zap className="w-4 h-4 text-indigo-400/50" />
//           </div>
//         </div>
//       </div>
//     );
//   }

//   const statCards = [
//     { title: 'Total Users', value: stats.totalUsers, icon: Users, change: `+${stats.newUsersToday} today`, href: '/admin/admin-users', accent: '#6366f1' },
//     { title: 'Total Quizzes', value: stats.totalQuizzes, icon: BookOpen, change: `+${stats.quizzesToday} today`, href: '/admin/admin-quizzes', accent: '#8b5cf6' },
//     { title: 'Active Users', value: stats.activeUsers, icon: Activity, change: 'last 7 days', href: '/admin/admin-users?filter=active', accent: '#10b981' },
//     { title: 'Completion Rate', value: `${stats.completionRate}%`, icon: Target, change: 'all time avg', href: '/admin/reports', accent: '#f59e0b' },
//   ];

//   return (
//     <div className="space-y-6 max-w-7xl">

//       {/* ─── HEADER ─── */}
//       <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
//         <div>
//           <h1 className="text-xl font-semibold text-white">Dashboard</h1>
//           <p className="text-sm text-white/30 mt-0.5">Welcome back. Here's what's happening.</p>
//         </div>
//         <div className="flex items-center gap-2">
//           <button
//             onClick={() => router.push('/admin/reports')}
//             className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm text-white/50 hover:text-white border border-white/[0.06] hover:border-white/12 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
//           >
//             <BarChart3 className="w-4 h-4" />
//             Reports
//           </button>
//           <button
//             onClick={() => router.push('/admin/admin-users')}
//             className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-white transition-all hover:opacity-90"
//             style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
//           >
//             <Users className="w-4 h-4" />
//             Manage Users
//           </button>
//         </div>
//       </div>

//       {/* ─── STAT CARDS ─── */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
//         {statCards.map((card) => <StatCard key={card.title} {...card} />)}
//       </div>

//       {/* ─── SECONDARY STATS ─── */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//         {[
//           { title: 'Total Attempts', value: stats.totalAttempts, icon: Award, sub: 'all time', accent: '#ec4899' },
//           { title: 'Average Score', value: `${stats.avgScore}%`, icon: TrendingUp, sub: 'across all quizzes', accent: '#f59e0b' },
//         ].map((s) => (
//           <div
//             key={s.title}
//             className="flex items-center justify-between p-5 rounded-2xl border"
//             style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(255,255,255,0.06)' }}
//           >
//             <div>
//               <p className="text-sm text-white/35 mb-1">{s.title}</p>
//               <p className="text-2xl font-semibold text-white">{s.value}</p>
//               <p className="text-xs text-white/20 mt-1">{s.sub}</p>
//             </div>
//             <div
//               className="w-12 h-12 rounded-2xl flex items-center justify-center"
//               style={{ background: `${s.accent}15`, border: `1px solid ${s.accent}22` }}
//             >
//               <s.icon className="w-5 h-5" style={{ color: s.accent }} />
//             </div>
//           </div>
//         ))}
//       </div>

//       {/* ─── BOTTOM ROW ─── */}
//       <div className="grid lg:grid-cols-3 gap-4">

//         {/* Recent Activity */}
//         <div
//           className="lg:col-span-2 rounded-2xl border overflow-hidden"
//           style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(255,255,255,0.06)' }}
//         >
//           <div
//             className="flex items-center justify-between px-5 py-4 border-b"
//             style={{ borderColor: 'rgba(255,255,255,0.05)' }}
//           >
//             <div className="flex items-center gap-2.5">
//               <Activity className="w-4 h-4 text-indigo-400" />
//               <h2 className="text-sm font-semibold text-white">Recent Activity</h2>
//             </div>
//             <Link href="/admin/reports" className="flex items-center gap-1 text-xs text-white/25 hover:text-white/50 transition-colors">
//               View all <ChevronRight className="w-3 h-3" />
//             </Link>
//           </div>

//           <div className="divide-y" style={{ divideColor: 'rgba(255,255,255,0.04)' }}>
//             {recentActivity.map((a) => (
//               <div
//                 key={a.id}
//                 className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer group"
//                 onClick={() => {
//                   if (a.type === 'user' && a.userId) router.push(`/admin/admin-users/${a.userId}`);
//                   else if (a.type === 'quiz' && a.quizId) router.push(`/admin/admin-quizzes/${a.quizId}`);
//                 }}
//               >
//                 <div
//                   className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
//                   style={{ background: 'rgba(255,255,255,0.04)' }}
//                 >
//                   {activityIcon(a.type)}
//                 </div>
//                 <div className="flex-1 min-w-0">
//                   <p className="text-sm text-white/70 group-hover:text-white transition-colors truncate">{a.message}</p>
//                   <p className="text-xs text-white/20 flex items-center gap-1 mt-0.5">
//                     <Calendar className="w-3 h-3" /> {a.time}
//                   </p>
//                 </div>
//                 <ChevronRight className="w-4 h-4 text-white/10 group-hover:text-white/30 transition-colors shrink-0" />
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Quick Actions */}
//         <div className="space-y-3">
//           <h2 className="text-sm font-semibold text-white/40 px-1">Quick Actions</h2>
//           {[
//             { href: '/admin/admin-users', icon: Users, title: 'User Management', desc: 'View, edit & manage all users', accent: '#6366f1' },
//             { href: '/admin/admin-quizzes', icon: BookOpen, title: 'Quiz Management', desc: 'Monitor & manage all quizzes', accent: '#8b5cf6' },
//             { href: '/admin/reports', icon: BarChart3, title: 'Analytics & Reports', desc: 'Detailed insights & data', accent: '#f59e0b' },
//           ].map((item) => (
//             <Link
//               key={item.href}
//               href={item.href}
//               className="group flex items-start gap-3.5 p-4 rounded-2xl border transition-all hover:scale-[1.02]"
//               style={{
//                 background: `${item.accent}08`,
//                 borderColor: `${item.accent}18`
//               }}
//               onMouseEnter={e => (e.currentTarget.style.borderColor = `${item.accent}35`)}
//               onMouseLeave={e => (e.currentTarget.style.borderColor = `${item.accent}18`)}
//             >
//               <div
//                 className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
//                 style={{ background: `${item.accent}18` }}
//               >
//                 <item.icon className="w-4 h-4" style={{ color: item.accent }} />
//               </div>
//               <div className="min-w-0">
//                 <p className="text-sm font-medium text-white">{item.title}</p>
//                 <p className="text-xs text-white/30 mt-0.5 leading-relaxed">{item.desc}</p>
//               </div>
//             </Link>
//           ))}
//         </div>

//       </div>
//     </div>
//   );
// }






'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  Users, 
  BookOpen, 
  CheckCircle, 
  Clock,
  TrendingUp,
  UserPlus,
  Award,
  Eye,
  ChevronRight,
  Calendar,
  Activity,
  Target,
  Zap,
  BarChart3
} from 'lucide-react';

interface Stats {
  totalUsers: number;
  totalQuizzes: number;
  activeUsers: number;
  completionRate: number;
  newUsersToday: number;
  quizzesToday: number;
  totalAttempts: number;
  avgScore: number;
}

interface RecentActivity {
  id: string;
  type: 'user' | 'quiz' | 'result';
  message: string;
  time: string;
  userId?: string;
  quizId?: string;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalQuizzes: 0,
    activeUsers: 0,
    completionRate: 0,
    newUsersToday: 0,
    quizzesToday: 0,
    totalAttempts: 0,
    avgScore: 0
  });
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch main stats
      const statsRes = await fetch('/api/admin/dashboard');
      const statsData = await statsRes.json();
      
      if (statsData.success) {
        setStats(statsData.data);
      }

      // Fetch recent activity
      const activityRes = await fetch('/api/admin/recent-activity');
      const activityData = await activityRes.json();
      
      if (activityData.success) {
        setRecentActivity(activityData.data);
      } else {
        // Fallback mock data
        setRecentActivity([
          { id: '1', type: 'user', message: 'New user registered', time: '2 minutes ago' },
          { id: '2', type: 'quiz', message: 'New quiz created', time: '15 minutes ago' },
          { id: '3', type: 'result', message: 'Quiz completed', time: '1 hour ago' },
          { id: '4', type: 'user', message: 'Teacher account approved', time: '2 hours ago' },
          { id: '5', type: 'quiz', message: 'Quiz attempted 50 times', time: '3 hours ago' },
        ]);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch(type) {
      case 'user': return <UserPlus className="w-4 h-4 text-blue-400" />;
      case 'quiz': return <BookOpen className="w-4 h-4 text-purple-400" />;
      case 'result': return <CheckCircle className="w-4 h-4 text-green-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="relative">
          <div className="w-12 h-12 border-4 border-white/10 border-t-white rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white/40 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Quick Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-white">Dashboard</h1>
          <p className="text-sm text-white/40 mt-1">
            Welcome back, Admin. Here's what's happening with your platform.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => router.push('/admin/reports')}
            className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm text-white/80 hover:text-white transition-colors flex items-center gap-2 border border-white/10"
          >
            <TrendingUp className="w-4 h-4" />
            View Reports
          </button>
          <button
            onClick={() => router.push('/admin/admin-users')}
            className="px-4 py-2 bg-white/10 hover:bg-white/15 rounded-lg text-sm text-white transition-colors flex items-center gap-2"
          >
            <Users className="w-4 h-4" />
            Manage Users
          </button>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            title: 'Total Users',
            value: stats.totalUsers,
            icon: Users,
            change: `+${stats.newUsersToday} today`,
            href: '/admin/admin-users',
            accent: '#6366f1'
          },
          {
            title: 'Total Quizzes',
            value: stats.totalQuizzes,
            icon: BookOpen,
            change: `+${stats.quizzesToday} today`,
            href: '/admin/admin-quizzes',
            accent: '#8b5cf6'
          },
          {
            title: 'Active Users',
            value: stats.activeUsers,
            icon: Activity,
            change: 'last 7 days',
            href: '/admin/admin-users?filter=active',
            accent: '#10b981'
          },
          {
            title: 'Completion Rate',
            value: `${stats.completionRate}%`,
            icon: Target,
            change: 'avg. score',
            href: '/admin/reports',
            accent: '#f59e0b'
          },
        ].map((stat) => (
          <Link
            key={stat.title}
            href={stat.href}
            className="group block bg-white/[0.02] border border-white/[0.05] rounded-xl p-6 hover:border-white/10 transition-all hover:scale-[1.02] cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div 
                className="p-3 rounded-lg border"
                style={{ background: `${stat.accent}18`, borderColor: `${stat.accent}25` }}
              >
                <stat.icon className="w-5 h-5" style={{ color: stat.accent }} />
              </div>
              <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors" />
            </div>
            <p className="text-2xl font-semibold text-white mb-1">{stat.value}</p>
            <p className="text-sm text-white/40 mb-2">{stat.title}</p>
            <p className="text-xs text-white/20 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {stat.change}
            </p>
          </Link>
        ))}
      </div>

      {/* Secondary Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { title: 'Total Attempts', value: stats.totalAttempts, icon: Award, change: 'all time', accent: '#ec4899' },
          { title: 'Avg. Score', value: `${stats.avgScore}%`, icon: TrendingUp, change: 'overall', accent: '#f59e0b' },
        ].map((stat) => (
          <div
            key={stat.title}
            className="bg-white/[0.02] border border-white/[0.05] rounded-xl p-4 flex items-center justify-between"
          >
            <div>
              <p className="text-sm text-white/40 mb-1">{stat.title}</p>
              <p className="text-2xl font-semibold text-white">{stat.value}</p>
              <p className="text-xs text-white/20 mt-1">{stat.change}</p>
            </div>
            <div 
              className="p-3 rounded-lg border"
              style={{ background: `${stat.accent}18`, borderColor: `${stat.accent}25` }}
            >
              <stat.icon className="w-5 h-5" style={{ color: stat.accent }} />
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity with Links */}
      <div className="bg-white/[0.02] border border-white/[0.05] rounded-xl overflow-hidden">
        <div className="p-5 border-b border-white/[0.05] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-medium text-white">Recent Activity</h2>
          </div>
          <Link
            href="/admin/reports"
            className="text-xs text-white/40 hover:text-white/60 transition-colors flex items-center gap-1"
          >
            View all
            <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
        
        <div className="divide-y divide-white/[0.05]">
          {recentActivity.map((activity) => (
            <div
              key={activity.id}
              className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02] transition-colors group cursor-pointer"
              onClick={() => {
                if (activity.type === 'user' && activity.userId) {
                  router.push(`/admin/admin-users/${activity.userId}`);
                } else if (activity.type === 'quiz' && activity.quizId) {
                  router.push(`/admin/admin-quizzes/${activity.quizId}`);
                }
              }}
            >
              <div className="w-8 h-8 rounded-full bg-white/[0.02] flex items-center justify-center group-hover:scale-110 transition-transform">
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1">
                <p className="text-sm text-white/80 group-hover:text-white transition-colors">
                  {activity.message}
                </p>
                <p className="text-xs text-white/30 flex items-center gap-1 mt-0.5">
                  <Calendar className="w-3 h-3" />
                  {activity.time}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors" />
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { href: '/admin/admin-users', icon: Users, title: 'User Management', desc: 'View, edit, and manage all users', accent: '#6366f1' },
          { href: '/admin/admin-quizzes', icon: BookOpen, title: 'Quiz Management', desc: 'Monitor and manage all quizzes', accent: '#8b5cf6' },
          { href: '/admin/reports', icon: BarChart3, title: 'Analytics', desc: 'View reports and insights', accent: '#f59e0b' },
        ].map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="group bg-gradient-to-br from-white/[0.02] to-transparent border border-white/[0.05] rounded-xl p-4 hover:scale-[1.02] transition-all"
          >
            <div className="flex items-center gap-3 mb-2">
              <div 
                className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{ background: `${item.accent}18` }}
              >
                <item.icon className="w-4 h-4" style={{ color: item.accent }} />
              </div>
              <span className="text-sm font-medium text-white">{item.title}</span>
            </div>
            <p className="text-xs text-white/40">{item.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}